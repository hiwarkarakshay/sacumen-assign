# import json
# import yaml
# from yaml.loader import SafeLoader
#
# def file(param, param1):
#     pass
#
#
# def getInstanceId():
#     pass
#
#
# instanceId = getInstanceId()
# stream = file('config.yaml', 'r')
# dict = yaml.load_all(stream)
#
# for key in dict:
#     if key in dict == "instanceId":
#         print(key, dict[key])
#
#
#
#
#
#
# # with open("config.yaml", "r") as ymlfile:
# # #     yl = yaml.load(ymlfile,Loader=SafeLoader)
# # #
# # # print("YAML File:-",yl)
#
# #
# # sports = getSport()
#
# #
# # def file(param, param1):
# #     pass
# #
# #
# # f1 = file('config.yaml','r')
# # dict = yaml.load_all(f1)
# #
# # for key in dict:
# #     if key in dict == "sports":
# #         print key , dict[key]
#
# # instanceId = getInstanceId()
# # stream = file('db.yml', 'r')
# # dict = yaml.load_all(stream)
# #
# # for key in dict:
# #     if key in dict == "instanceId":
# #         print key, dict[key]
# #
#
#
#
#
#
# # Load the configuration file
# # with open("config.ini") as f:
# #     sample_config = f.read()
# #
# # print("INI file:-",sample_config)
#
#
# # with open("config.xml") as f:
# #     content = f.read()
# #
# # print("XML file:-",content)
#
#
# # with open("config.json") as json_data_file:
# #     data = json.load(json_data_file)
# # print("JSON File:-",data)

from .myfunction import *
